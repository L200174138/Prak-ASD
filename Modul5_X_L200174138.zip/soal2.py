a=[1,2,3,4,5,6]
b=[11,10,9,7,8,12]

def swap(x,a,b):
    temp=x[a]
    x[a]=x[b]
    x[b]=temp

def sort(x,y):
    a=[]
    m=len(y)
    for i in range(m):
        a.append(y[i])
    n=len(x)
    for i in range(n):
        a.append(x[i])
    o=len(a)
    for i in range(o-1):
        for j in range(o-i-1):
            if a[j]>a[j+1]:
                swap(a,j,j+1)
    print(a)