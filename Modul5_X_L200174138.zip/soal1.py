#Soal 1
def swap(A,p,q):
    tmp = A[p]
    A[p] = A[q]
    A[q] = tmp

class MhsTIF(object):
    def __init__(self,nama,NIM,kota,us):
        """Metode inisiasi ini menutupi metode inisiasi di class Manusia"""
        self.nama = nama
        self.NIM = NIM
        self.kotaTinggal = kota
        self.uangSaku = us
    
    def __str__(self):
        x=str(self.NIM)+" "+self.nama+" "+self.kotaTinggal+" "+str(self.uangSaku)
        return x
    
    def ambilNama(self):
        return self.nama
    def ambilNim(self):
        return self.NIM
    def ambilKota(self):
        return self.kotaTinggal
    def ambilUangSaku(self):
        return self.uangSaku

c0 = MhsTIF('Ika',1,'Sukoharjo',2400000)
c1 = MhsTIF('Budi',3,'Seragen',230000)
c2 = MhsTIF('Ahmad',2,'Surakarta',250000)
c3 = MhsTIF('Chandra',5,'Surakarta',235000)
c4 = MhsTIF('Eka',4,'Boyolali',240000)
c5 = MhsTIF('Fandi',7,'Salatiga',250000)
c6 = MhsTIF('Deni',8,'Klaten',245000)
c7 = MhsTIF('Galuh',6,'Wonogiri',245000)
c8 = MhsTIF('Janto',9,'Klaten',245000)
c9 = MhsTIF('Hasan',10,'Karanganyar',270000)
c10 = MhsTIF('Khalid',11,'Purwodadi',265000)

Daftar = [c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10]

def mhsSort(A):
    n= len(A)
    for i in range(1,n):
        nilai = A[i]
        pos = i
        while pos>0 and nilai.NIM<A[pos-1].NIM:
            A[pos]=A[pos-1]
            pos=pos-1
        A[pos] = nilai

mhsSort(Daftar)
print('\n'.join(map(str, Daftar)))