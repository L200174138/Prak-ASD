"""
   Nama  = Muhammad Rafi
   NIM   = L200174138
   No 1,2,3,4
"""

class MhsTIF(object):
    def __init__(self, nama, umur, kota, us):
        self.nama = nama
        self.umur = umur
        self.kotaTinggal = kota
        self.uangSaku = us

    def __str__(self):
        x = self.nama + ', umur' + str(self.umur) \
            + '. Tinggal di ' + self.kotaTinggal \
            + '. Uang saku ' + str(self.uangSaku) \
            + 'tiap bulannya.'
        return x

    def ambilNama(self):
        return self.nama
    def ambilUmur(self):
        return self.umur
    def ambilKota(self):
        return self.kotaTinggal
    def ambilUangSaku(self):
        return self.uangSaku

c0 = MhsTIF('Gery', 13, 'Yogyakarta', 300000)
c1 = MhsTIF('Jhony', 11, 'Palembang', 250000)
c2 = MhsTIF('Natali', 16, 'Kudus', 500000)
c3 = MhsTIF('Roni', 17, 'Solo', 370000)
c4 = MhsTIF('Surip', 15, 'Jakarta', 400000)
c5 = MhsTIF('Rahma', 20, 'Karawang', 350000)
c6 = MhsTIF('Joko', 21, 'Bekasi', 450000)
c7 = MhsTIF('Sandi', 22, 'Karanganyar', 380000)
c8 = MhsTIF('Alan', 9, 'Jayapura', 270000)
c9 = MhsTIF('Raka', 7, 'Salatiga', 340000)
c10 = MhsTIF('Rani', 8, 'Balikpapan', 750000)

Daftar = [c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10]

    """
        No 1
    """
def cariKota(target):
    z = []
    for i in Daftar:
        if i.kotaTinggal == target:
            hasil = Daftar.index(i)
            z.append(hasil)
    return z

    """
        No 2
    """
def cariTerkecil(Daftar):
    n = len(Daftar)
    terkecil = Daftar[0]
    for i in range(1,n):
        if Daftar[i].uangSaku < terkecil.uangSaku:
            terkecil = Daftar[i]

    return terkecil

    """
        No 3
    """
def cariTerkecil(Daftar):
    n = len(Daftar)
    terkecil = [Daftar[0]]
    for i in range(1,n):
        if Daftar[i].uangSaku < terkecil[0].uangSaku:
            terkecil = [Daftar[i]]
        elif Daftar[i].uangSaku == terkecil[0].uangSaku:
            terkecil.append(Daftar[i])
    return terkecil

    """
        No 4
    """
def cariDaftarUangSakuKurang(kumpulan):
    b = []  
    for i in kumpulan:
        if i.uangSaku < 300000:
            terkecil = i.uangSaku
            b.append(kumpulan.index(i))
    return b
